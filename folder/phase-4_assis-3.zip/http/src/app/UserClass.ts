export class UserClass{
    id:number;
    name:string;
    username:string;
    email:string;
}
