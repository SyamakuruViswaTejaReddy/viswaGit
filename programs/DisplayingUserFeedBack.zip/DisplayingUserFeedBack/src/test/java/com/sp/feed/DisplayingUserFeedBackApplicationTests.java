package com.sp.feed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisplayingUserFeedBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
