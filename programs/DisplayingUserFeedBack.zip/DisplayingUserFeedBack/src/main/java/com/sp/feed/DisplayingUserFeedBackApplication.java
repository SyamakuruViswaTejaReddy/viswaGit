package com.sp.feed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.sp.feed")
public class DisplayingUserFeedBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisplayingUserFeedBackApplication.class, args);
	}

}
