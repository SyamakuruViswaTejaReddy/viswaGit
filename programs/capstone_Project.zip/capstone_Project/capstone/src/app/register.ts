export class register{
    mobile:string;
    pass:string;
}