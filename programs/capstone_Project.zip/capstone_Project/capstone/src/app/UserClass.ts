export class UserClass{
    id:number;
    name:string;
    mobile:string;
    address:string;
    dob:Date;
    dor:Date;
    gender:string;
}