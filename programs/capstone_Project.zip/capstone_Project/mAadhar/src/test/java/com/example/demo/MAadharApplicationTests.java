package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MAadharApplicationTests {

	@Test
	void contextLoads() {
	}

}
